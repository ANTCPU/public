import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, Database, Server, Cpu, Activity, Clock, Shield, AlertTriangle } from 'lucide-react';
import Ledger from './components/Ledger';
import SprintManager from './components/SprintManager';
import CharterExplorer from './components/CharterExplorer';
import AgentRoster from './components/AgentRoster';

interface QueueItem {
  id: number;
  priority: string;
  task: string;
  file: string;
  effort: string;
  status: string;
  dependency: string;
}

export default function App() {
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [status, setStatus] = useState<any>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [command, setCommand] = useState('');
  const [isStudioMode, setIsStudioMode] = useState(false);
  const [isClockedIn, setIsClockedIn] = useState(false);
  const [activePanel, setActivePanel] = useState<'DASHBOARD' | 'QUEUE' | 'OPS'>('DASHBOARD');
  const [handshakes, setHandshakes] = useState<any[]>([]);
  const [tokenMetrics] = useState({
    total_requests: 85,
    avg_latency: '1,295ms',
    error_rate: 25
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [qRes, sRes, hRes, cRes] = await Promise.all([
          fetch('/api/queue'),
          fetch('/api/status'),
          fetch('/api/handshakes'),
          fetch('/api/clock/status/antcpu-master')
        ]);
        const qData = await qRes.json();
        const sData = await sRes.json();
        const hData = await hRes.json();
        const cData = await cRes.json();
        setQueue(qData);
        setStatus(sData);
        setHandshakes(hData);
        setIsClockedIn(cData.isClockedIn);
        if (sData.logs) {
          setLogs(prev => {
            const allLogs = [...sData.logs, ...prev];
            const uniqueLogs = [...new Set(allLogs)].slice(0, 10);
            if (!uniqueLogs.includes('[UI] LEDGER_EXPANSION_COMPLETE: TOKEN_METRICS_INTEGRATED')) {
              uniqueLogs.unshift('[UI] LEDGER_EXPANSION_COMPLETE: TOKEN_METRICS_INTEGRATED');
            }
            return uniqueLogs.slice(0, 10);
          });
        }
      } catch (e) {
        // Error logged via silent fail or retry
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command) return;
    
    try {
      const res = await fetch('/api/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cmd: command })
      });
      const data = await res.json();
      if (data.output) {
        setLogs(prev => [`> ${command}`, `[SYS] ${data.output}`, ...prev].slice(0, 10));
      } else {
        setLogs(prev => [`> ${command}`, `[ERR] ${data.error}`, ...prev].slice(0, 10));
      }
    } catch (err) {
      setLogs(prev => [`> ${command}`, `[ERR] CONNECTION_FAILED`, ...prev].slice(0, 10));
    }
    setCommand('');
  };

  const triggerDoorbell = async () => {
    await fetch('/api/iot/doorbell', { method: 'POST', body: JSON.stringify({ vibration: 2.1 }) });
    setLogs(prev => [`[IOT] DOORBELL_SIGNAL_EMITTED`, ...prev].slice(0, 10));
  };

  const handleClock = async (type: 'in' | 'out') => {
    try {
      const res = await fetch(`/api/clock/${type}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identityId: 'antcpu-master' })
      });
      const data = await res.json();
      if (data.success) {
        setLogs(prev => [`[CLK] MASTER_${type.toUpperCase()}_SUCCESS`, ...prev].slice(0, 10));
        setIsClockedIn(type === 'in');
      } else {
        setLogs(prev => [`[ERR] ${data.error}`, ...prev].slice(0, 10));
      }
    } catch (err) {
      setLogs(prev => [`[ERR] CLOCK_ACTION_FAILED`, ...prev].slice(0, 10));
    }
  };

  const approveTask = async (id: number) => {
    try {
      const res = await fetch(`/api/tasks/approve/${id}`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setLogs(prev => [`[HITL] APPROVAL_GRANTED: TASK_${id}`, ...prev].slice(0, 10));
        const qRes = await fetch('/api/queue');
        setQueue(await qRes.json());
      }
    } catch (err) {
      setLogs(prev => [`[ERR] APPROVAL_FAILED`, ...prev].slice(0, 10));
    }
  };

  const getPriorityTag = (p: string) => {
    switch(p) {
      case 'HIGH': return { label: 'P0', color: 'text-[#FF3E3E] underline underline-offset-4' };
      case 'MED': return { label: 'P1', color: 'text-[#FFA500]' };
      default: return { label: 'P2', color: 'text-[#AAA]' };
    }
  };

  return (
    <div className={`min-h-screen bg-[#0A0A0A] text-[#E0E0E0] font-sans flex flex-col p-4 md:p-12 select-none selection:bg-white selection:text-black transition-all duration-700 ${isStudioMode ? 'bg-[#050505]' : ''}`}>
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-[#333] pb-6 mb-8 group gap-4">
        <div className="flex flex-col w-full md:w-auto">
          <span className="text-[#666] font-mono text-[10px] md:text-xs tracking-widest uppercase mb-2">System Operator // antcpu.io</span>
          <h1 className="text-5xl md:text-8xl font-black tracking-tighter text-white leading-none flex items-center justify-between md:justify-start gap-4">
            FORGE
            <button 
              onClick={() => setIsStudioMode(!isStudioMode)}
              className="text-[10px] font-mono border border-[#333] px-3 py-2 uppercase tracking-widest text-[#444] hover:text-white hover:border-white transition-all opacity-100 md:opacity-0 md:group-hover:opacity-100"
            >
              {isStudioMode ? '[EXIT]' : '[STUDIO]'}
            </button>
          </h1>
        </div>
        <div className="text-left md:text-right w-full md:w-auto border-t md:border-t-0 border-[#222] pt-4 md:pt-0">
          <div className="font-mono text-xs text-[#00FF41] mb-1 tracking-widest">[ STATUS: {status?.status || 'OFFLINE'} ]</div>
          <div className="text-xs text-[#666] tracking-widest uppercase">{status?.version || 'V1.0.0'}_PRODUCTION</div>
        </div>
      </header>

      {/* Mobile Panel Nav - Hidden on Desktop */}
      {!isStudioMode && (
        <div className="flex md:hidden border border-[#333] mb-6 font-mono text-[10px]">
          {(['DASHBOARD', 'QUEUE', 'OPS'] as const).map(p => (
            <button
              key={p}
              onClick={() => setActivePanel(p)}
              className={`flex-1 py-3 uppercase tracking-widest transition-all ${activePanel === p ? 'bg-white text-black font-bold' : 'text-[#666]'}`}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Main Grid */}
      <main className="grid grid-cols-1 md:grid-cols-12 gap-8 flex-grow">
        {/* Sidebar Loadout */}
        <section className={`${isStudioMode ? 'hidden' : activePanel === 'DASHBOARD' ? 'block' : 'hidden'} md:block md:col-span-3 flex flex-col gap-10`}>
          <div>
            <h2 className="text-[10px] font-bold tracking-[0.2em] text-[#666] uppercase border-b border-[#333] pb-2 mb-4">System Loadout</h2>
            <ul className="font-mono text-[11px] space-y-2">
              <li className="flex justify-between"><span className="text-[#999]">HOST</span> <span className="text-white">VERCEL/IONOS</span></li>
              <li className="flex justify-between"><span className="text-[#999]">CORE</span> <span className="text-white">NODE.JS</span></li>
              <li className="flex justify-between"><span className="text-[#999]">DB</span> <span className="text-white">SQLITE (ANTCPU)</span></li>
              <li className="flex justify-between"><span className="text-[#999]">REPO</span> <span className="text-white">GITHUB</span></li>
            </ul>
          </div>

          <div>
            <h2 className="text-[10px] font-bold tracking-[0.2em] text-[#666] uppercase border-b border-[#333] pb-2 mb-4">System Event Log</h2>
            <div className="font-mono text-[10px] space-y-1 h-32 overflow-hidden flex flex-col-reverse text-[#888]">
              {logs.map((log, i) => (
                <div key={i} className="truncate opacity-80 border-l border-[#333] pl-2">
                  {log}
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-[10px] font-bold tracking-[0.2em] text-[#666] uppercase border-b border-[#333] pb-2 mb-4">Runner Health</h2>
            <div className="font-mono text-[9px] space-y-2">
              <div className="flex justify-between items-center text-[#00FF41]">
                <span>KERNEL_PRIMARY</span>
                <span className="text-[8px]">[ACTIVE]</span>
              </div>
              <div className="flex justify-between items-center text-[#888]">
                <span>AGENT_AUDITOR</span>
                <span className="text-[8px] opacity-40">[IDLE]</span>
              </div>
              <div className="flex justify-between items-center text-[#00FF41]">
                <span>AGENT_ARIA</span>
                <span className="text-[8px] animate-pulse">[STANDBY]</span>
              </div>
              <div className="flex justify-between items-center text-[#888]">
                <span>SYNC_PROCTOR</span>
                <span className="text-[8px] opacity-40">[IDLE]</span>
              </div>
            </div>
          </div>

          <div className="mt-auto space-y-4">
            <div className="flex gap-2">
              <button 
                onClick={() => handleClock('in')}
                disabled={isClockedIn}
                className={`flex-1 py-2 border font-mono text-[10px] transition-all uppercase ${isClockedIn ? 'border-[#FFA500]/50 bg-[#FFA500]/20 text-[#FFA500] cursor-default' : 'border-[#00FF41]/30 bg-[#00FF41]/5 text-[#00FF41] hover:bg-[#00FF41]/10'}`}
              >
                {isClockedIn ? 'Clocked_In' : 'Clock_In'}
              </button>
              <button 
                onClick={() => handleClock('out')}
                disabled={!isClockedIn}
                className={`flex-1 py-2 border font-mono text-[10px] transition-all uppercase ${!isClockedIn ? 'border-[#333] bg-[#111] text-[#444] cursor-not-allowed' : 'border-[#FF3E3E]/30 bg-[#FF3E3E]/5 text-[#FF3E3E] hover:bg-[#FF3E3E]/10'}`}
              >
                Clock_Out
              </button>
            </div>
            
            <button 
              onClick={triggerDoorbell}
              className="w-full py-2 border border-[#888]/30 bg-[#888]/5 text-[#888] font-mono text-[10px] hover:bg-white hover:text-black transition-all uppercase"
            >
              Simulate_Doorbell
            </button>
            
            <div className="p-4 border border-[#333] bg-[#111]">
              <span className="text-[10px] font-bold text-[#666] uppercase block mb-1 flex items-center gap-2">
                <AlertTriangle className="h-3 w-3 text-amber-500" /> Warning
              </span>
              <p className="text-xs text-[#AAA] italic leading-tight">High severity drift detected in time_clock/identities synchronization.</p>
            </div>

            <form onSubmit={handleCommand} className="relative">
              <input 
                type="text"
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                placeholder="EXEC_COMMAND..."
                className="w-full bg-transparent border border-[#333] p-2 font-mono text-[10px] text-white focus:outline-none focus:border-white transition-all pl-6"
              />
              <span className="absolute left-2 top-2.5 text-[#666] font-mono text-[10px] select-none">&gt;</span>
            </form>
          </div>
        </section>

        {/* Central Build Queue */}
        <section className={`${isStudioMode ? 'block' : activePanel === 'QUEUE' ? 'block' : 'hidden'} md:block md:col-span-9 flex flex-col transition-all duration-700 ${isStudioMode ? 'scale-[1.01] opacity-100' : ''}`}>
          {isStudioMode ? (
            <div className="flex-grow flex flex-col gap-6 bg-[#000] border border-[#333] p-4 md:p-8 font-mono relative">
              <div className="absolute top-4 right-4 text-[9px] md:text-[10px] text-[#00FF41] animate-pulse">● STUDIO_MODE_ACTIVE</div>
              <div className="flex-grow space-y-4 overflow-y-auto pr-4 scrollbar-hide">
                <div className="text-[#666] italic text-[10px] md:text-sm">// INITIALIZING_DIALOGUE_FEED...</div>
                {logs.slice().reverse().map((log, i) => (
                  <div key={i} className="flex gap-2 md:gap-4 border-l border-[#222] pl-2 md:pl-4">
                    <span className="text-white/20 whitespace-nowrap text-[9px] md:text-xs">[{new Date().toLocaleTimeString()}]</span>
                    <span className={`text-[10px] md:text-sm ${log.includes('ARIA') ? 'text-pink-500' : log.includes('FORGE') ? 'text-[#00FF41]' : 'text-white/60'}`}>
                      {log}
                    </span>
                  </div>
                ))}
                {handshakes.map((h, i) => (
                  <div key={`h-${i}`} className="space-y-4">
                    <div className="flex gap-2 md:gap-4 border-l border-[#222] pl-2 md:pl-4 bg-white/5 py-2">
                       <span className="text-white/20 whitespace-nowrap text-[9px] md:text-xs">[{new Date(h.created_at).toLocaleTimeString()}]</span>
                       <span className="text-[#00FF41] text-[10px] md:text-sm">FORGE &gt; ARIA: {h.payload}</span>
                    </div>
                    <div className="flex gap-2 md:gap-4 border-l border-[#222] pl-2 md:pl-4">
                       <span className="text-white/20 whitespace-nowrap text-[9px] md:text-xs">[{new Date(h.created_at).toLocaleTimeString()}]</span>
                       <span className="text-pink-500 italic text-[10px] md:text-sm">ARIA: [GENERATING_CONTENT_PACKAGE...]</span>
                    </div>
                    <div className="ml-4 md:ml-8 space-y-1 text-[#666] text-[9px] md:text-[10px] border-l border-pink-500/20 pl-2 md:pl-4">
                      <div>1. TECH_DISCORD: "SYSTEM_READY. TASK_${h.task_id} FINALIZED."</div>
                      <div>2. X_REEL: "HIGH_SPEED_FORGE_UPDATE // #ANTCOIN"</div>
                      <div>3. PI_ANNOUNCEMENT: "MAP_OF_PI_ECOSYSTEM_EXPANSION_COMPLETE"</div>
                    </div>
                  </div>
                ))}
              </div>
              <form onSubmit={handleCommand} className="mt-auto border-t border-[#333] pt-6 flex gap-4">
                <span className="text-[#00FF41] md:text-lg">&gt;&gt;</span>
                <input 
                  autoFocus
                  type="text"
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  className="bg-transparent flex-grow outline-none text-white text-[10px] md:text-sm"
                  placeholder="AGENT_COMM_IDLE..."
                />
              </form>
            </div>
          ) : (
            <>
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl md:text-2xl font-serif italic text-white">Build_Queue</h2>
                <span className="hidden md:block px-2 py-1 bg-white text-black font-mono text-[10px] font-bold uppercase">Mode: Structured_Engineering_Decisions</span>
              </div>

              <div className="w-full border border-[#333] flex-grow overflow-x-auto bg-[#0D0D0D]">
                <table className="w-full text-left font-mono text-[10px] md:text-[11px] min-w-[600px]">
                  <thead>
                    <tr className="bg-[#1a1a1a] border-b border-[#333] text-[#666]">
                      <th className="py-3 px-4 font-normal uppercase tracking-wider">PRIORITY</th>
                      <th className="py-3 px-4 font-normal uppercase tracking-wider">TASK</th>
                      <th className="py-3 px-4 font-normal uppercase tracking-wider">FILE</th>
                      <th className="py-3 px-4 font-normal uppercase tracking-wider">EFFORT</th>
                      <th className="py-3 px-4 font-normal uppercase tracking-wider">STATUS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#222]">
                    <AnimatePresence mode="popLayout">
                      {queue.map((item, i) => {
                        const tag = getPriorityTag(item.priority);
                        return (
                          <motion.tr 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ delay: i * 0.05 }}
                            key={item.task + i} 
                            className="hover:bg-[#151515] transition-colors group cursor-pointer"
                          >
                            <td className={`py-4 px-4 font-bold ${tag.color}`}>
                              {tag.label}
                            </td>
                            <td className="py-4 px-4 text-white uppercase tracking-tight">
                              {item.status === 'COMPLETE' ? (
                                <span className="line-through text-white/30">{item.task}</span>
                              ) : item.task}
                            </td>
                            <td className="py-4 px-4 text-[#AAA] lowercase italic truncate max-w-[100px]">{item.file}</td>
                            <td className="py-4 px-4 text-[#888]">{item.effort}</td>
                            <td className="py-4 px-4">
                              {item.status === 'AWAITING_HUMAN_SENSE_CHECK' ? (
                                <button 
                                  onClick={() => approveTask(item.id)}
                                  className="w-full bg-white text-black py-2 px-3 font-bold text-[9px] hover:bg-[#00FF41] transition-all min-h-[44px]"
                                >
                                  [APPROVE]
                                </button>
                              ) : (
                                <span className={`px-2 py-1 font-mono text-[9px] font-bold ${item.status === 'COMPLETE' ? 'text-[#00FF41]' : 'text-[#FFA500]'}`}>
                                  [{item.status}]
                                </span>
                              )}
                            </td>
                          </motion.tr>
                        );
                      })}
                    </AnimatePresence>
                  </tbody>
                </table>
              </div>
            </>
          )}

          <footer className="mt-6 flex flex-col md:flex-row justify-between items-start md:items-center text-[9px] md:text-[10px] text-[#444] font-mono tracking-widest uppercase gap-4">
            <div className="grid grid-cols-2 md:flex md:gap-6 gap-y-2 w-full md:w-auto">
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-[#00FF41] rounded-full" /> [FORGE: ONLINE]</span>
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-pink-500 rounded-full" /> [ARIA: STANDBY]</span>
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-[#222] rounded-full" /> [AGNT-D: IDLE]</span>
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-[#222] rounded-full" /> [AGNT-E: IDLE]</span>
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-[#222] rounded-full" /> [AGNT-F: IDLE]</span>
              <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-[#222] rounded-full" /> [AGNT-G: IDLE]</span>
            </div>
            <div className="border-t border-[#1a1a1a] pt-2 md:pt-0 w-full md:w-auto">FORGE_EXECUTION_LEVEL_01</div>
          </footer>

          <div className={`${activePanel === 'QUEUE' ? 'block' : 'hidden md:block'} mt-8`}>
            <SprintManager 
              queue={queue} 
              onRefresh={async () => {
                const res = await fetch('/api/queue');
                setQueue(await res.json());
              }} 
            />
          </div>

          <div className={`${activePanel === 'OPS' ? 'block' : 'hidden md:block'} space-y-8`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Ledger metrics={tokenMetrics} />
              {/* Optional: Add second column content or center ledger */}
            </div>
            <CharterExplorer />
            <AgentRoster />
          </div>
        </section>
      </main>
    </div>
  );
}
