import React, { useEffect, useState } from 'react';
import { Target, ShieldCheck, Compass } from 'lucide-react';

interface Charter {
  id: string;
  name: string;
  objective: string;
  constraints: string;
}

export default function CharterExplorer() {
  const [charters, setCharters] = useState<Charter[]>([]);
  const [active, setActive] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/charters')
      .then(res => res.json())
      .then(setCharters)
      .catch(() => {});
  }, []);

  return (
    <div className="mt-8 border border-[#333] bg-[#0A0A0A] p-4 font-mono">
      <div className="flex justify-between items-center mb-4 border-b border-[#333] pb-2">
        <h2 className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em]">Agent_Charters</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {charters.map(charter => (
          <div 
            key={charter.id}
            onClick={() => setActive(charter.id === active ? null : charter.id)}
            className={`p-4 border transition-all cursor-pointer min-h-[80px] flex flex-col justify-center ${active === charter.id ? 'border-white bg-white/5' : 'border-[#222] hover:border-[#444]'}`}
          >
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className={`h-3 w-3 ${active === charter.id ? 'text-white' : 'text-[#666]'}`} />
              <div className="text-[9px] font-bold uppercase tracking-widest">{charter.id}</div>
            </div>
            <div className="text-[11px] font-bold text-white mb-1 truncate">{charter.name}</div>
            
            {active === charter.id && (
              <div className="mt-4 space-y-3 pt-3 border-t border-[#333]">
                <div>
                  <div className="text-[8px] text-[#666] uppercase mb-1 flex items-center gap-1">
                    <Target className="h-2 w-2" /> Objective
                  </div>
                  <p className="text-[10px] text-[#AAA] italic leading-relaxed">{charter.objective}</p>
                </div>
                <div>
                  <div className="text-[8px] text-[#666] uppercase mb-1 flex items-center gap-1">
                    <Compass className="h-2 w-2" /> Constraints
                  </div>
                  <p className="text-[10px] text-[#888] leading-relaxed">{charter.constraints}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
