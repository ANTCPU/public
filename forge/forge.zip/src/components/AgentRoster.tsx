import React, { useEffect, useState } from 'react';
import { Users, ExternalLink, Sparkles } from 'lucide-react';

interface AgentProfile {
  name: string;
  role: string;
  status: 'ACTIVE' | 'COMING_SOON';
  svgSeed?: string;
}

export default function AgentRoster() {
  const [agents, setAgents] = useState<AgentProfile[]>([
    { name: 'FORGE', role: 'Kernel / Engineering', status: 'ACTIVE' },
    { name: 'ARIA', role: 'Marketing / Growth', status: 'ACTIVE' },
    { name: 'AUDITOR', role: 'Finance / Compliance', status: 'COMING_SOON' },
    { name: 'PROCTOR', role: 'Sync / Security', status: 'COMING_SOON' },
  ]);

  useEffect(() => {
    // Attempt to fetch fresh data from antcpu.com/employees.html
    // Note: In a real scenario, we'd parse the HTML. For now, we'll keep the static list as base.
    fetch('https://antcpu.com/employees.html')
      .then(res => res.text())
      .then(html => {
        console.log('[AGENT_ROSTER] Syncing with antcpu.com...');
        // Logic to parse and update agents would go here
      })
      .catch(() => console.log('[AGENT_ROSTER] Use fallback roster'));
  }, []);

  return (
    <div className="mt-8 border border-[#333] bg-[#0A0A0A] p-4 font-mono">
      <div className="flex justify-between items-center mb-6 border-b border-[#333] pb-2">
        <h2 className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] flex items-center gap-2">
          <Users className="h-3 w-3" /> Agent_Network_Roster
        </h2>
        <div className="text-[8px] text-[#444] animate-pulse uppercase tracking-widest">Live_Sync_Active</div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {agents.map((agent) => (
          <div 
            key={agent.name}
            className={`relative p-4 border flex flex-col items-center text-center transition-all group ${
              agent.status === 'ACTIVE' ? 'border-[#333] hover:border-white' : 'border-dashed border-[#222] opacity-50'
            }`}
          >
            {agent.status === 'COMING_SOON' && (
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-10 pointer-events-none">
                <div className="bg-white text-black text-[7px] font-black px-2 py-0.5 rotate-[-5deg] tracking-tighter uppercase whitespace-nowrap">
                  Coming_Soon
                </div>
              </div>
            )}
            
            {/* SVG Face Placeholder */}
            <div className={`w-12 h-12 mb-3 rounded-full flex items-center justify-center border ${
              agent.status === 'ACTIVE' ? 'border-[#444] group-hover:border-white' : 'border-[#222]'
            }`}>
              <span className={`text-[8px] font-bold ${agent.status === 'ACTIVE' ? 'text-white' : 'text-[#444]'}`}>
                {agent.name.charAt(0)}
              </span>
            </div>

            <div className={`text-[10px] font-bold uppercase tracking-widest mb-1 ${
              agent.status === 'ACTIVE' ? 'text-white' : 'text-[#444]'
            }`}>
              {agent.name}
            </div>
            <div className="text-[8px] text-[#666] uppercase leading-tight mb-3">
              {agent.role}
            </div>

            {agent.status === 'ACTIVE' && (
              <a 
                href={`https://antcpu.com/${agent.name.toLowerCase()}`}
                target="_blank"
                rel="noreferrer"
                className="mt-auto flex items-center gap-1 text-[8px] text-[#444] hover:text-white transition-colors"
              >
                Access_Node <ExternalLink className="h-2 w-2" />
              </a>
            )}
          </div>
        ))}

        {/* Global Coming Soon Banner */}
        <div className="col-span-2 md:col-span-4 mt-4 p-3 bg-white/5 border border-[#1a1a1a] flex items-center justify-between overflow-hidden relative">
          <div className="flex items-center gap-3">
            <Sparkles className="h-3 w-3 text-white animate-pulse" />
            <div className="flex flex-col">
              <span className="text-[9px] text-white font-bold uppercase tracking-widest">Expanding_Agent_Ecosystem</span>
              <span className="text-[8px] text-[#666] uppercase italic">Syncing with antcpu.com/employees ...</span>
            </div>
          </div>
          <div className="text-[12px] font-black text-[#1a1a1a] tracking-tighter uppercase absolute right-[-10px] opacity-20 select-none">
            Scale_Operation_Forge
          </div>
        </div>
      </div>
    </div>
  );
}
