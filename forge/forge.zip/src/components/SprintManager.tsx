import React, { useState } from 'react';
import { Plus, CheckCircle2, Circle } from 'lucide-react';

interface SprintTask {
  id: number;
  task: string;
  status: string;
  priority: string;
}

export default function SprintManager({ queue, onRefresh }: { queue: any[], onRefresh: () => void }) {
  const [newTask, setNewTask] = useState('');

  const addTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask) return;
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        task: newTask.toUpperCase(), 
        priority: 'MED', 
        effort: 'S',
        status: 'PENDING'
      })
    });
    setNewTask('');
    onRefresh();
  };

  const toggleTask = async (id: number, currentStatus: string) => {
    await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: currentStatus === 'COMPLETE' ? 'PENDING' : 'COMPLETE' })
    });
    onRefresh();
  };

  return (
    <div className="mt-8 border border-[#333] bg-[#0A0A0A] p-4 font-mono">
      <div className="flex justify-between items-center mb-4 border-b border-[#333] pb-2">
        <h2 className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em]">Sprint_Tracker</h2>
      </div>

      <form onSubmit={addTask} className="mb-4 flex gap-2">
        <input 
          type="text" 
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="NEW_TASK_ENTRY..."
          className="flex-grow bg-black border border-[#333] p-1 text-[10px] text-white focus:outline-none focus:border-white"
        />
        <button type="submit" className="px-2 border border-[#333] hover:bg-white hover:text-black transition-all">
          <Plus className="h-3 w-3" />
        </button>
      </form>

      <div className="space-y-3">
        {queue.slice(0, 8).map((t, i) => (
          <div 
            key={i} 
            onClick={() => toggleTask(t.id, t.status)}
            className="flex items-center justify-between p-2 border border-white/0 hover:border-white/10 transition-all cursor-pointer min-h-[44px]"
          >
            <div className="flex items-center gap-3">
              {t.status === 'COMPLETE' ? (
                <CheckCircle2 className="h-4 w-4 text-[#00FF41]" />
              ) : t.status === 'AWAITING_HUMAN_SENSE_CHECK' ? (
                <div className="h-4 w-4 rounded-full border-2 border-white animate-pulse" />
              ) : (
                <Circle className="h-4 w-4 text-[#444] group-hover:text-white" />
              )}
              <div className="flex flex-col">
                <span className={`text-[10px] uppercase tracking-tighter ${t.status === 'COMPLETE' ? 'text-[#333] line-through' : 'text-[#888]'}`}>
                  {t.task}
                </span>
                {t.status === 'AWAITING_HUMAN_SENSE_CHECK' && (
                  <span className="text-[7px] text-white font-bold opacity-50 uppercase tracking-widest">[PENDING_HITL]</span>
                )}
              </div>
            </div>
            <div className="text-[8px] text-[#444]">{t.priority}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
