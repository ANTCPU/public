import React, { useEffect, useState } from 'react';

interface LedgerEntry {
  id: number;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  timestamp: string;
}

interface LedgerProps {
  metrics?: {
    total_requests: number;
    avg_latency: string;
    error_rate: number;
  };
}

export default function Ledger({ metrics }: LedgerProps) {
  const [entries, setEntries] = useState<LedgerEntry[]>([]);

  useEffect(() => {
    fetch('/api/ledger')
      .then(res => res.json())
      .then(setEntries)
      .catch(() => {});
  }, []);

  const balance = entries.reduce((acc, curr) => 
    curr.type === 'credit' ? acc + curr.amount : acc - curr.amount, 0
  );

  return (
    <div className="mt-8 border border-[#333] bg-[#0A0A0A] p-4 font-mono">
      <div className="flex justify-between items-center mb-4 border-b border-[#333] pb-2">
        <h2 className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em]">Financial_Ledger</h2>
        <div className={`text-xs font-bold ${balance >= 0 ? 'text-[#00FF41]' : 'text-[#FF3E3E]'}`}>
          TOTAL_BAL: {balance.toFixed(2)} USD
        </div>
      </div>
      
      <div className="space-y-1 h-32 overflow-y-auto mb-6">
        {entries.length === 0 ? (
          <div className="text-[10px] text-[#444] italic">NO_RECORDS_FOUND</div>
        ) : (
          entries.map(entry => (
            <div key={entry.id} className="flex justify-between text-[10px] border-b border-[#111] py-1">
              <span className="text-[#888] truncate mr-4">{entry.description}</span>
              <span className={entry.type === 'credit' ? 'text-[#00FF41]' : 'text-[#FF3E3E]'}>
                {entry.type === 'credit' ? '+' : '-'}{entry.amount.toFixed(2)}
              </span>
            </div>
          ))
        )}
      </div>

      <div className="border-t-2 border-[#1a1a1a] pt-4">
        <h3 className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-3">[ SUBSYSTEM_CONSUMPTION ]</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center border-b border-[#111] pb-1">
            <span className="text-[9px] text-[#666] uppercase tracking-tighter">Req_Count</span>
            <span className="text-xs text-white font-medium">{metrics?.total_requests || 0}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[#111] pb-1">
            <span className="text-[9px] text-[#666] uppercase tracking-tighter">Avg_Latency</span>
            <span className="text-xs text-white font-medium">{metrics?.avg_latency || '0ms'}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[9px] text-[#666] uppercase tracking-tighter">Health_Index</span>
            <span className={`text-[9px] font-bold ${(metrics?.error_rate || 0) < 10 ? 'text-[#00FF41]' : 'text-[#FF3E3E]'}`}>
              {(metrics?.error_rate || 0) < 10 ? '[STABLE]' : `[DEGRADED (${metrics?.error_rate}%)]`}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
