import express from 'express';
import { createServer as createViteServer } from 'vite';
import cors from 'cors';
import path from 'path';
import db from './lib/db.ts';
import { syncIdentitiesAndContacts, cleanupStaleSessions } from './services/sync.ts';
import { clockIn, clockOut } from './services/clock.ts';
import { iot } from './lib/iot.ts';

const FORGE_API_KEY = 'AIzaSyAeKXA_npvcHejYxbcVYvhjdqJyQKYKGRI';

async function startServer() {
  const app = express();
  const PORT = 3000;

  const systemLogs: string[] = [
    `[SYSTEM] MULTI_AGENT_PLATFORM_V1_DEPLOYED: ARIA_JOINED_OFFICE`,
    `[SYSTEM] FORGE_AUTH_KEY_INTEGRATED`
  ];

  // Run initial maintenance tasks
  syncIdentitiesAndContacts(FORGE_API_KEY);
  cleanupStaleSessions(FORGE_API_KEY);
  
  // Generate Monthly Report if missing
  const now = new Date();
  const monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  const currentMonth = monthNames[now.getMonth()];
  const currentYear = now.getFullYear();
  
  const checkReport = db.prepare('SELECT id FROM monthly_records WHERE month = ? AND year = ?').get(currentMonth, currentYear);
  if (!checkReport) {
    const totalLedger = db.prepare('SELECT SUM(amount) as bal FROM ledger').get() as { bal: number };
    const balance = totalLedger.bal || 0;
    db.prepare('INSERT INTO monthly_records (month, year, summary) VALUES (?, ?, ?)').run(
      currentMonth, 
      currentYear, 
      `BALANCE: ${balance.toFixed(2)} USD // SYSTEM_OPERATIONAL`
    );
  }

  // Mark Sprint Tracker Complete
  db.prepare("UPDATE tasks SET status = 'COMPLETE' WHERE task = 'SPRINT_TASK_TRACKER'").run();

  // Periodic maintenance every 15 minutes
  setInterval(() => {
    syncIdentitiesAndContacts(FORGE_API_KEY);
    cleanupStaleSessions(FORGE_API_KEY);
    systemLogs.unshift(`[${new Date().toLocaleTimeString()}] MAINTENANCE_CYCLE_COMPLETE`);
  }, 900000);

  app.use(cors());
  app.use(express.json());

  // API Routes
  app.get('/api/status', (req, res) => {
    res.json({ 
      status: 'ONLINE', 
      system: 'FORGE', 
      version: '1.0.0',
      logs: systemLogs.slice(0, 5)
    });
  });

  app.get('/api/identities', (req, res) => {
    const identities = db.prepare('SELECT * FROM identities').all();
    res.json(identities);
  });

  app.get('/api/projects', (req, res) => {
    const projects = db.prepare('SELECT * FROM projects ORDER BY priority DESC').all();
    res.json(projects);
  });

  app.get('/api/time-clock', (req, res) => {
    const records = db.prepare('SELECT tc.*, i.name as identity_name FROM time_clock tc JOIN identities i ON tc.identity_id = i.id ORDER BY clock_in DESC LIMIT 50').all();
    res.json(records);
  });

  app.get('/api/clock/status/:identityId', (req, res) => {
    const { identityId } = req.params;
    const active = db.prepare('SELECT id, clock_in FROM time_clock WHERE identity_id = ? AND clock_out IS NULL').get(identityId);
    res.json({ isClockedIn: !!active, session: active });
  });

  app.post('/api/clock/in', (req, res) => {
    try {
      const { identityId, notes } = req.body;
      const id = clockIn(identityId, notes);
      res.json({ success: true, id });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/clock/out', (req, res) => {
    try {
      const { identityId } = req.body;
      clockOut(identityId);
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/command', (req, res) => {
    const { cmd } = req.body;
    // Simple command simulation for FORGE environment
    if (cmd === 'sync --force') {
      syncIdentitiesAndContacts(FORGE_API_KEY);
      return res.json({ output: 'FORCE SYNC TRIGGERED. CONTACTS RE-LINKED.' });
    }
    if (cmd === 'kill --stale') {
      cleanupStaleSessions(FORGE_API_KEY);
      return res.json({ output: 'STALE SESSIONS PURGED.' });
    }
    res.status(404).json({ error: 'COMMAND_NOT_RECOGNIZED' });
  });

  app.post('/api/iot/doorbell', (req, res) => {
    const result = iot.triggerDoorbell(req.body.vibration);
    res.json(result);
  });

  app.get('/api/ledger', (req, res) => {
    const ledger = db.prepare('SELECT * FROM ledger ORDER BY timestamp DESC LIMIT 100').all();
    res.json(ledger);
  });

  app.post('/api/ledger', (req, res) => {
    const { description, amount, type } = req.body;
    const result = db.prepare('INSERT INTO ledger (description, amount, type) VALUES (?, ?, ?)').run(description, amount, type);
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.post('/api/tasks', (req, res) => {
    const { priority, task, file, effort, dependency } = req.body;
    const result = db.prepare('INSERT INTO tasks (priority, task, file, effort, dependency) VALUES (?, ?, ?, ?, ?)').run(priority, task, file, effort, dependency);
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.patch('/api/tasks/:id', (req, res) => {
    const { status } = req.body;
    const { id } = req.params;
    db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run(status, id);
    res.json({ success: true });
  });

  app.post('/api/tasks/approve/:id', (req, res) => {
    const { id } = req.params;
    db.prepare("UPDATE tasks SET status = 'COMPLETE' WHERE id = ?").run(id);
    
    // Trigger Handshake with Aria
    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id) as any;
    const summary = `TASK_FINALIZED: ${task.task}. FILE: ${task.file}. SYSTEM: FORGE.`;
    
    db.prepare('INSERT INTO agent_handshakes (source_agent, target_agent, payload, task_id) VALUES (?, ?, ?, ?)').run(
      'FORGE', 'ARIA', summary, id
    );

    res.json({ success: true, message: 'HITL_APPROVAL_GRANTED' });
  });

  app.get('/api/handshakes', (req, res) => {
    const handshakes = db.prepare('SELECT * FROM agent_handshakes ORDER BY created_at DESC LIMIT 10').all();
    res.json(handshakes);
  });

  app.post('/api/projects', (req, res) => {
    const { id, name, description, priority } = req.body;
    db.prepare('INSERT INTO projects (id, name, description, priority) VALUES (?, ?, ?, ?)').run(id, name, description, priority);
    res.json({ success: true });
  });

  app.get('/api/reports/monthly', (req, res) => {
    const records = db.prepare('SELECT * FROM monthly_records ORDER BY year DESC, month DESC').all();
    res.json(records);
  });

  app.post('/api/reports/monthly', (req, res) => {
    const { month, year, summary } = req.body;
    db.prepare('INSERT OR REPLACE INTO monthly_records (month, year, summary) VALUES (?, ?, ?)').run(month, year, summary);
    res.json({ success: true });
  });

  app.get('/api/charters', (req, res) => {
    const charters = db.prepare('SELECT * FROM agent_charters ORDER BY id ASC').all();
    res.json(charters);
  });

  app.get('/api/runs', (req, res) => {
    const runs = db.prepare(`
      SELECT r.*, p.name as project_name 
      FROM runner_runs r 
      LEFT JOIN projects p ON r.project_id = p.id 
      ORDER BY start_time DESC 
      LIMIT 20
    `).all();
    res.json(runs);
  });

  // Task Queue / Build Queue API
  app.get('/api/queue', (req, res) => {
    const tasks = db.prepare("SELECT * FROM tasks ORDER BY CASE status WHEN 'PENDING' THEN 1 ELSE 2 END, CASE priority WHEN 'HIGH' THEN 1 WHEN 'MED' THEN 2 ELSE 3 END, id ASC").all();
    res.json(tasks.map(t => ({
      priority: t.priority,
      task: t.task,
      file: t.file,
      effort: t.effort,
      status: t.status,
      dependency: t.dependency
    })));
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FORGE SYSTEM OPERATIONAL ON PORT ${PORT}`);
  });
}

startServer();
