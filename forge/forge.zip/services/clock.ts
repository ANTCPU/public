import db from '../lib/db.ts';

export function clockIn(identityId: string, notes?: string) {
  // Check if already clocked in
  const active = db.prepare('SELECT id FROM time_clock WHERE identity_id = ? AND clock_out IS NULL').get(identityId);
  if (active) {
    throw new Error('IDENTITY_ALREADY_CLOCKED_IN');
  }

  const result = db.prepare('INSERT INTO time_clock (identity_id, notes) VALUES (?, ?)').run(identityId, notes || null);
  
  // Mark task for HITL check if it was the P0
  db.prepare("UPDATE tasks SET status = 'AWAITING_HUMAN_SENSE_CHECK' WHERE task = 'FIX_HARDCODED_ID'").run();
  
  return result.lastInsertRowid;
}

export function clockOut(identityId: string) {
  const result = db.prepare(`
    UPDATE time_clock 
    SET clock_out = CURRENT_TIMESTAMP 
    WHERE identity_id = ? AND clock_out IS NULL
  `).run(identityId);

  if (result.changes === 0) {
    throw new Error('NO_ACTIVE_SESSION_FOUND');
  }

  return true;
}
