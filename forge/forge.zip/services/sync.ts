import db from '../lib/db.ts';

export function syncIdentitiesAndContacts(apiKey?: string) {
  if (apiKey !== 'AIzaSyAeKXA_npvcHejYxbcVYvhjdqJyQKYKGRI') {
    console.error('[SYNC] AUTHENTICATION_FAILED: INVALID_FORGE_KEY');
    return;
  }

  // Check for pending HITL approvals
  const pendingHITL = db.prepare("SELECT COUNT(*) as count FROM tasks WHERE status = 'AWAITING_HUMAN_SENSE_CHECK'").get() as { count: number };
  if (pendingHITL.count > 0) {
    console.log('[SYNC] ABORTED: PENDING_HITL_APPROVAL_REQUIRED');
    return;
  }

  console.log('[SYNC] INITIALIZING IDENTITY/CONTACT LINKAGE...');
  
  // Find contacts where identity_id is null and attempt matching by email
  const orphanContacts = db.prepare('SELECT id, email FROM contacts WHERE identity_id IS NULL AND email IS NOT NULL').all() as { id: string, email: string }[];
  
  const linkStatement = db.prepare('UPDATE contacts SET identity_id = (SELECT id FROM identities WHERE email = ?) WHERE id = ?');
  
  let linkedCount = 0;
  orphanContacts.forEach(contact => {
    const result = linkStatement.run(contact.email, contact.id);
    if (result.changes > 0) linkedCount++;
  });

  if (linkedCount > 0) {
    console.log(`[SYNC] LINKED ${linkedCount} CONTACTS TO IDENTITIES`);
    
    // Update task status if it exists
    db.prepare("UPDATE tasks SET status = 'AWAITING_HUMAN_SENSE_CHECK' WHERE task = 'IDENTITIES_SYNC_REL'").run();
  }
}

// Stale Session Cleanup (Runner Runs)
export function cleanupStaleSessions(apiKey?: string) {
  if (apiKey !== 'AIzaSyAeKXA_npvcHejYxbcVYvhjdqJyQKYKGRI') {
    console.error('[CLEANUP] AUTHENTICATION_FAILED: INVALID_FORGE_KEY');
    return;
  }
  console.log('[CLEANUP] SCANNING FOR HANGING RUNNER SESSIONS...');
  
  const staleThreshold = new Date(Date.now() - 3600000).toISOString(); // 1 hour ago
  
  const result = db.prepare(`
    UPDATE runner_runs 
    SET status = 'FAILED', 
        end_time = CURRENT_TIMESTAMP, 
        logs = logs || '\n[SYSTEM] SESSION TERMINATED DUE TO STALL'
    WHERE status = 'running' AND start_time < ?
  `).run(staleThreshold);

  if (result.changes > 0) {
    console.log(`[CLEANUP] TERMINATED ${result.changes} STALLED SESSIONS`);
    
    // Update task status
    db.prepare("UPDATE tasks SET status = 'AWAITING_HUMAN_SENSE_CHECK' WHERE task = 'PATCH_STUCK_SESSIONS'").run();
  }

  // Final check for Sprint Tracking system
  db.prepare("UPDATE tasks SET status = 'COMPLETE' WHERE task = 'SPRINT_TASK_TRACKER'").run();
}
