import { EventEmitter } from 'events';
import db from './db.ts';

class IOTCore extends EventEmitter {
  constructor() {
    super();
    this.on('doorbell_press', (payload) => {
      console.log(`[IOT] DOORBELL_PRESS_DETECTED: ${payload.vibration_level}G`);
      db.prepare("UPDATE tasks SET status = 'COMPLETE' WHERE task = 'DOORBELL_SYSTEM_INIT'").run();
    });
  }

  triggerDoorbell(vibrationLevel: number = 1.2) {
    this.emit('doorbell_press', { 
      timestamp: new Date().toISOString(),
      vibration_level: vibrationLevel 
    });
    return { status: 'SIGNAL_EMITTED', vibration: vibrationLevel };
  }
}

export const iot = new IOTCore();
