import Database from 'better-sqlite3';
import { join } from 'path';

const db = new Database('antcpu.db');

// Initialize schema
db.exec(`
  CREATE TABLE IF NOT EXISTS identities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    role TEXT DEFAULT 'operator',
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS contacts (
    id TEXT PRIMARY KEY,
    identity_id TEXT REFERENCES identities(id),
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    company TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS time_clock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    identity_id TEXT REFERENCES identities(id),
    clock_in DATETIME DEFAULT CURRENT_TIMESTAMP,
    clock_out DATETIME,
    notes TEXT
  );

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'pending',
    priority INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS runner_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT REFERENCES projects(id),
    agent_id TEXT,
    start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    end_time DATETIME,
    status TEXT DEFAULT 'running',
    logs TEXT
  );

  CREATE TABLE IF NOT EXISTS agent_charters (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    objective TEXT,
    constraints TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    type TEXT CHECK(type IN ('credit', 'debit')),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS monthly_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    month TEXT NOT NULL,
    year INTEGER NOT NULL,
    summary TEXT,
    UNIQUE(month, year)
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    priority TEXT CHECK(priority IN ('HIGH', 'MED', 'LOW')),
    task TEXT NOT NULL,
    file TEXT,
    effort TEXT CHECK(effort IN ('S', 'M', 'L', 'XL')),
    status TEXT DEFAULT 'PENDING',
    dependency TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed Tasks if empty
const taskCount = db.prepare('SELECT COUNT(*) as count FROM tasks').get() as { count: number };
if (taskCount.count === 0) {
  const insertTask = db.prepare('INSERT INTO tasks (priority, task, file, effort, status, dependency) VALUES (?, ?, ?, ?, ?, ?)');
  const initialTasks = [
    ['HIGH', 'FIX_HARDCODED_ID', 'time_clock.js', 'S', 'PENDING', 'identities'],
    ['HIGH', 'PATCH_STUCK_SESSIONS', 'runner_runs.js', 'S', 'PENDING', 'NONE'],
    ['MED', 'IDENTITIES_SYNC_REL', 'contacts.js', 'M', 'PENDING', 'identities'],
    ['LOW', 'DOORBELL_SYSTEM_INIT', 'iot_core.js', 'L', 'PENDING', 'NONE'],
    ['LOW', 'SPRINT_TASK_TRACKER', 'projects.js', 'XL', 'PENDING', 'PROJECTS']
  ];
  initialTasks.forEach(task => insertTask.run(...task));
}

// Seed Agent Charters
const charterCount = db.prepare('SELECT COUNT(*) as count FROM agent_charters').get() as { count: number };
if (charterCount.count === 0) {
  const insertCharter = db.prepare('INSERT INTO agent_charters (id, name, objective, constraints) VALUES (?, ?, ?, ?)');
  const initialCharters = [
    ['SYS-001', 'FORGE_KERNEL', 'Maintain core system stability and API consistency.', 'Minimal resource footprint; zero-trust auth.'],
    ['AGNT-A', 'SYNC_PROCTOR', 'Ensure identity/contact synchronization across distributed nodes.', 'Strict rate limiting; idempotent operations.'],
    ['AGNT-B', 'FINANCIAL_AUDITOR', 'Monitor ledger entries and flag anomalous transactions.', 'Read-only access to time_clock; write to monthly_records.'],
    ['AGNT-C', 'ARIA', 'Execute multi-channel marketing synchronization for Map of Pi and Antcoin.', 'Align with ecosystem visual guidelines; maintain brand voice.']
  ];
  initialCharters.forEach(charter => insertCharter.run(...charter));
}

// Add communication table
db.exec(`
  CREATE TABLE IF NOT EXISTS agent_handshakes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_agent TEXT,
    target_agent TEXT,
    payload TEXT,
    response TEXT,
    task_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Insert default operator if not exists
const checkOperator = db.prepare('SELECT id FROM identities WHERE id = ?');
const insertOperator = db.prepare('INSERT INTO identities (id, name, email, role) VALUES (?, ?, ?, ?)');

const defaultOpId = 'antcpu-master';
if (!checkOperator.get(defaultOpId)) {
  insertOperator.run(defaultOpId, 'ANTCPU Operator', 'antcpu@gmail.com', 'admin');
}

export default db;
